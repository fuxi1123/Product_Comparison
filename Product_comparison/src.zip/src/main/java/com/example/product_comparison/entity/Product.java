package com.example.product_comparison.entity;

public class Product {
}
