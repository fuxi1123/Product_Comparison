package com.example.product_comparison;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductComparisonApplicationTests {

    @Test
    void contextLoads() {
    }

}
